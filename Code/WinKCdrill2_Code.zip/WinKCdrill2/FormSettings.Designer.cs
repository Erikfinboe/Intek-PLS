﻿namespace winKCdrill2
{
	// Token: 0x0200000C RID: 12
	//[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
	public partial class FormSettings : global::System.Windows.Forms.Form
	{
		// Token: 0x060000D2 RID: 210 RVA: 0x00032DC4 File Offset: 0x000311C4
		[global::System.Diagnostics.DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x00032DE4 File Offset: 0x000311E4
		[global::System.Diagnostics.DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			this.GroupBox4 = new global::System.Windows.Forms.GroupBox();
			this.NUpStigBotten = new global::System.Windows.Forms.NumericUpDown();
			this.Label22 = new global::System.Windows.Forms.Label();
			this.NUpBottDjup = new global::System.Windows.Forms.NumericUpDown();
			this.NUpBinderBott = new global::System.Windows.Forms.NumericUpDown();
			this.Label3 = new global::System.Windows.Forms.Label();
			this.Label4 = new global::System.Windows.Forms.Label();
			this.GroupBox3 = new global::System.Windows.Forms.GroupBox();
			this.NUpStigTopp = new global::System.Windows.Forms.NumericUpDown();
			this.Label21 = new global::System.Windows.Forms.Label();
			this.NUpTopDjup = new global::System.Windows.Forms.NumericUpDown();
			this.NUpBinderTop = new global::System.Windows.Forms.NumericUpDown();
			this.Label1 = new global::System.Windows.Forms.Label();
			this.Label2 = new global::System.Windows.Forms.Label();
			this.GroupBox2 = new global::System.Windows.Forms.GroupBox();
			this.NUpAutoStop = new global::System.Windows.Forms.NumericUpDown();
			this.NUpBinder = new global::System.Windows.Forms.NumericUpDown();
			this.Label7 = new global::System.Windows.Forms.Label();
			this.Label6 = new global::System.Windows.Forms.Label();
			this.NUpStigning = new global::System.Windows.Forms.NumericUpDown();
			this.Label9 = new global::System.Windows.Forms.Label();
			this.GroupBox5 = new global::System.Windows.Forms.GroupBox();
			this.NUpJoyRot = new global::System.Windows.Forms.NumericUpDown();
			this.NUpJoyUppNer = new global::System.Windows.Forms.NumericUpDown();
			this.Label5 = new global::System.Windows.Forms.Label();
			this.Label8 = new global::System.Windows.Forms.Label();
			this.GroupBox6 = new global::System.Windows.Forms.GroupBox();
			this.NupDiameter = new global::System.Windows.Forms.NumericUpDown();
			this.Label20 = new global::System.Windows.Forms.Label();
			this.NUpRotMaxPelTillV = new global::System.Windows.Forms.NumericUpDown();
			this.Label18 = new global::System.Windows.Forms.Label();
			this.NUpÖnskadRotDrill = new global::System.Windows.Forms.NumericUpDown();
			this.NUpMixFrånA = new global::System.Windows.Forms.NumericUpDown();
			this.Label11 = new global::System.Windows.Forms.Label();
			this.Label10 = new global::System.Windows.Forms.Label();
			this.GroupBox7 = new global::System.Windows.Forms.GroupBox();
			this.CheckStartUpMedel = new global::System.Windows.Forms.CheckBox();
			this.CheckCellAuto = new global::System.Windows.Forms.CheckBox();
			this.CheckMaxUpSpeed = new global::System.Windows.Forms.CheckBox();
			this.GroupBox8 = new global::System.Windows.Forms.GroupBox();
			this.NUpRegFaktor = new global::System.Windows.Forms.NumericUpDown();
			this.NUpEgetStartV = new global::System.Windows.Forms.NumericUpDown();
			this.NUpAntalStartV = new global::System.Windows.Forms.NumericUpDown();
			this.NUpMaxUppBits = new global::System.Windows.Forms.NumericUpDown();
			this.NUpMinUppBits = new global::System.Windows.Forms.NumericUpDown();
			this.TextSpare = new global::System.Windows.Forms.TextBox();
			this.Label15 = new global::System.Windows.Forms.Label();
			this.Label16 = new global::System.Windows.Forms.Label();
			this.Label17 = new global::System.Windows.Forms.Label();
			this.Label12 = new global::System.Windows.Forms.Label();
			this.Label13 = new global::System.Windows.Forms.Label();
			this.Label14 = new global::System.Windows.Forms.Label();
			this.Button1 = new global::System.Windows.Forms.Button();
			this.Button2 = new global::System.Windows.Forms.Button();
			this.tmrÄndringsKoll = new global::System.Windows.Forms.Timer(this.components);
			this.Label19 = new global::System.Windows.Forms.Label();
			this.GroupBox1 = new global::System.Windows.Forms.GroupBox();
			this.CheckTankBoff = new global::System.Windows.Forms.CheckBox();
			this.CheckTankAoff = new global::System.Windows.Forms.CheckBox();
			this.GroupBox4.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NUpStigBotten).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpBottDjup).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpBinderBott).BeginInit();
			this.GroupBox3.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NUpStigTopp).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpTopDjup).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpBinderTop).BeginInit();
			this.GroupBox2.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NUpAutoStop).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpBinder).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpStigning).BeginInit();
			this.GroupBox5.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NUpJoyRot).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpJoyUppNer).BeginInit();
			this.GroupBox6.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NupDiameter).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpRotMaxPelTillV).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpÖnskadRotDrill).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpMixFrånA).BeginInit();
			this.GroupBox7.SuspendLayout();
			this.GroupBox8.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NUpRegFaktor).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpEgetStartV).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpAntalStartV).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpMaxUppBits).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpMinUppBits).BeginInit();
			this.GroupBox1.SuspendLayout();
			this.SuspendLayout();
			this.GroupBox4.Controls.Add(this.NUpStigBotten);
			this.GroupBox4.Controls.Add(this.Label22);
			this.GroupBox4.Controls.Add(this.NUpBottDjup);
			this.GroupBox4.Controls.Add(this.NUpBinderBott);
			this.GroupBox4.Controls.Add(this.Label3);
			this.GroupBox4.Controls.Add(this.Label4);
			global::System.Windows.Forms.Control groupBox = this.GroupBox4;
			global::System.Drawing.Point location = new global::System.Drawing.Point(653, 45);
			groupBox.Location = location;
			this.GroupBox4.Name = "GroupBox4";
			global::System.Windows.Forms.Control groupBox2 = this.GroupBox4;
			global::System.Drawing.Size size = new global::System.Drawing.Size(305, 107);
			groupBox2.Size = size;
			this.GroupBox4.TabIndex = 2;
			this.GroupBox4.TabStop = false;
			this.GroupBox4.Text = "Different Start (Bottom)";
			this.NUpStigBotten.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpStigBotten.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupStigBotten = this.NUpStigBotten;
			location = new global::System.Drawing.Point(167, 75);
			nupStigBotten.Location = location;
			global::System.Windows.Forms.NumericUpDown nupStigBotten2 = this.NUpStigBotten;
			decimal num = new decimal(new int[]
			{
				50,
				0,
				0,
				0
			});
			nupStigBotten2.Maximum = num;
			this.NUpStigBotten.Name = "NUpStigBotten";
			global::System.Windows.Forms.Control nupStigBotten3 = this.NUpStigBotten;
			size = new global::System.Drawing.Size(74, 22);
			nupStigBotten3.Size = size;
			this.NUpStigBotten.TabIndex = 17;
			this.NUpStigBotten.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupStigBotten4 = this.NUpStigBotten;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupStigBotten4.Value = num;
			this.Label22.AutoSize = true;
			this.Label22.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label = this.Label22;
			location = new global::System.Drawing.Point(13, 77);
			label.Location = location;
			this.Label22.Name = "Label22";
			global::System.Windows.Forms.Control label2 = this.Label22;
			size = new global::System.Drawing.Size(130, 16);
			label2.Size = size;
			this.Label22.TabIndex = 16;
			this.Label22.Text = "Speed Up (mm/rpm)";
			this.NUpBottDjup.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpBottDjup.DecimalPlaces = 2;
			this.NUpBottDjup.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.NumericUpDown nupBottDjup = this.NUpBottDjup;
			num = new decimal(new int[]
			{
				1,
				0,
				0,
				65536
			});
			nupBottDjup.Increment = num;
			global::System.Windows.Forms.Control nupBottDjup2 = this.NUpBottDjup;
			location = new global::System.Drawing.Point(167, 46);
			nupBottDjup2.Location = location;
			global::System.Windows.Forms.NumericUpDown nupBottDjup3 = this.NUpBottDjup;
			num = new decimal(new int[]
			{
				25,
				0,
				0,
				0
			});
			nupBottDjup3.Maximum = num;
			this.NUpBottDjup.Name = "NUpBottDjup";
			global::System.Windows.Forms.Control nupBottDjup4 = this.NUpBottDjup;
			size = new global::System.Drawing.Size(74, 22);
			nupBottDjup4.Size = size;
			this.NUpBottDjup.TabIndex = 9;
			this.NUpBottDjup.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.NUpBinderBott.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpBinderBott.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupBinderBott = this.NUpBinderBott;
			location = new global::System.Drawing.Point(167, 15);
			nupBinderBott.Location = location;
			global::System.Windows.Forms.NumericUpDown nupBinderBott2 = this.NUpBinderBott;
			num = new decimal(new int[]
			{
				500,
				0,
				0,
				0
			});
			nupBinderBott2.Maximum = num;
			this.NUpBinderBott.Name = "NUpBinderBott";
			global::System.Windows.Forms.Control nupBinderBott3 = this.NUpBinderBott;
			size = new global::System.Drawing.Size(74, 22);
			nupBinderBott3.Size = size;
			this.NUpBinderBott.TabIndex = 8;
			this.NUpBinderBott.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.Label3.AutoSize = true;
			this.Label3.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label3 = this.Label3;
			location = new global::System.Drawing.Point(13, 48);
			label3.Location = location;
			this.Label3.Name = "Label3";
			global::System.Windows.Forms.Control label4 = this.Label3;
			size = new global::System.Drawing.Size(94, 16);
			label4.Size = size;
			this.Label3.TabIndex = 6;
			this.Label3.Text = "Stop Level (m)";
			this.Label4.AutoSize = true;
			this.Label4.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label5 = this.Label4;
			location = new global::System.Drawing.Point(13, 17);
			label5.Location = location;
			this.Label4.Name = "Label4";
			global::System.Windows.Forms.Control label6 = this.Label4;
			size = new global::System.Drawing.Size(88, 16);
			label6.Size = size;
			this.Label4.TabIndex = 4;
			this.Label4.Text = "Binder (kg/m)";
			this.GroupBox3.Controls.Add(this.NUpStigTopp);
			this.GroupBox3.Controls.Add(this.Label21);
			this.GroupBox3.Controls.Add(this.NUpTopDjup);
			this.GroupBox3.Controls.Add(this.NUpBinderTop);
			this.GroupBox3.Controls.Add(this.Label1);
			this.GroupBox3.Controls.Add(this.Label2);
			global::System.Windows.Forms.Control groupBox3 = this.GroupBox3;
			location = new global::System.Drawing.Point(341, 45);
			groupBox3.Location = location;
			this.GroupBox3.Name = "GroupBox3";
			global::System.Windows.Forms.Control groupBox4 = this.GroupBox3;
			size = new global::System.Drawing.Size(306, 107);
			groupBox4.Size = size;
			this.GroupBox3.TabIndex = 1;
			this.GroupBox3.TabStop = false;
			this.GroupBox3.Text = "Different in Top";
			this.NUpStigTopp.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpStigTopp.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupStigTopp = this.NUpStigTopp;
			location = new global::System.Drawing.Point(169, 75);
			nupStigTopp.Location = location;
			global::System.Windows.Forms.NumericUpDown nupStigTopp2 = this.NUpStigTopp;
			num = new decimal(new int[]
			{
				50,
				0,
				0,
				0
			});
			nupStigTopp2.Maximum = num;
			this.NUpStigTopp.Name = "NUpStigTopp";
			global::System.Windows.Forms.Control nupStigTopp3 = this.NUpStigTopp;
			size = new global::System.Drawing.Size(74, 22);
			nupStigTopp3.Size = size;
			this.NUpStigTopp.TabIndex = 17;
			this.NUpStigTopp.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupStigTopp4 = this.NUpStigTopp;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupStigTopp4.Value = num;
			this.Label21.AutoSize = true;
			this.Label21.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label7 = this.Label21;
			location = new global::System.Drawing.Point(15, 77);
			label7.Location = location;
			this.Label21.Name = "Label21";
			global::System.Windows.Forms.Control label8 = this.Label21;
			size = new global::System.Drawing.Size(130, 16);
			label8.Size = size;
			this.Label21.TabIndex = 16;
			this.Label21.Text = "Speed Up (mm/rpm)";
			this.NUpTopDjup.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpTopDjup.DecimalPlaces = 2;
			this.NUpTopDjup.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.NumericUpDown nupTopDjup = this.NUpTopDjup;
			num = new decimal(new int[]
			{
				1,
				0,
				0,
				65536
			});
			nupTopDjup.Increment = num;
			global::System.Windows.Forms.Control nupTopDjup2 = this.NUpTopDjup;
			location = new global::System.Drawing.Point(169, 47);
			nupTopDjup2.Location = location;
			global::System.Windows.Forms.NumericUpDown nupTopDjup3 = this.NUpTopDjup;
			num = new decimal(new int[]
			{
				25,
				0,
				0,
				0
			});
			nupTopDjup3.Maximum = num;
			this.NUpTopDjup.Name = "NUpTopDjup";
			global::System.Windows.Forms.Control nupTopDjup4 = this.NUpTopDjup;
			size = new global::System.Drawing.Size(74, 22);
			nupTopDjup4.Size = size;
			this.NUpTopDjup.TabIndex = 9;
			this.NUpTopDjup.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.NUpBinderTop.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpBinderTop.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupBinderTop = this.NUpBinderTop;
			location = new global::System.Drawing.Point(169, 15);
			nupBinderTop.Location = location;
			global::System.Windows.Forms.NumericUpDown nupBinderTop2 = this.NUpBinderTop;
			num = new decimal(new int[]
			{
				500,
				0,
				0,
				0
			});
			nupBinderTop2.Maximum = num;
			this.NUpBinderTop.Name = "NUpBinderTop";
			global::System.Windows.Forms.Control nupBinderTop3 = this.NUpBinderTop;
			size = new global::System.Drawing.Size(74, 22);
			nupBinderTop3.Size = size;
			this.NUpBinderTop.TabIndex = 8;
			this.NUpBinderTop.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.Label1.AutoSize = true;
			this.Label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label9 = this.Label1;
			location = new global::System.Drawing.Point(15, 49);
			label9.Location = location;
			this.Label1.Name = "Label1";
			global::System.Windows.Forms.Control label10 = this.Label1;
			size = new global::System.Drawing.Size(93, 16);
			label10.Size = size;
			this.Label1.TabIndex = 6;
			this.Label1.Text = "Start Level (m)";
			this.Label2.AutoSize = true;
			this.Label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label11 = this.Label2;
			location = new global::System.Drawing.Point(15, 21);
			label11.Location = location;
			this.Label2.Name = "Label2";
			global::System.Windows.Forms.Control label12 = this.Label2;
			size = new global::System.Drawing.Size(88, 16);
			label12.Size = size;
			this.Label2.TabIndex = 4;
			this.Label2.Text = "Binder (kg/m)";
			this.GroupBox2.Controls.Add(this.NUpAutoStop);
			this.GroupBox2.Controls.Add(this.NUpBinder);
			this.GroupBox2.Controls.Add(this.Label7);
			this.GroupBox2.Controls.Add(this.Label6);
			this.GroupBox2.Controls.Add(this.NUpStigning);
			this.GroupBox2.Controls.Add(this.Label9);
			global::System.Windows.Forms.Control groupBox5 = this.GroupBox2;
			location = new global::System.Drawing.Point(28, 45);
			groupBox5.Location = location;
			this.GroupBox2.Name = "GroupBox2";
			global::System.Windows.Forms.Control groupBox6 = this.GroupBox2;
			size = new global::System.Drawing.Size(304, 107);
			groupBox6.Size = size;
			this.GroupBox2.TabIndex = 0;
			this.GroupBox2.TabStop = false;
			this.GroupBox2.Text = "Normal Column";
			this.NUpAutoStop.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpAutoStop.DecimalPlaces = 2;
			this.NUpAutoStop.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.NumericUpDown nupAutoStop = this.NUpAutoStop;
			num = new decimal(new int[]
			{
				1,
				0,
				0,
				65536
			});
			nupAutoStop.Increment = num;
			global::System.Windows.Forms.Control nupAutoStop2 = this.NUpAutoStop;
			location = new global::System.Drawing.Point(160, 46);
			nupAutoStop2.Location = location;
			global::System.Windows.Forms.NumericUpDown nupAutoStop3 = this.NUpAutoStop;
			num = new decimal(new int[]
			{
				25,
				0,
				0,
				0
			});
			nupAutoStop3.Maximum = num;
			global::System.Windows.Forms.NumericUpDown nupAutoStop4 = this.NUpAutoStop;
			num = new decimal(new int[]
			{
				1,
				0,
				0,
				65536
			});
			nupAutoStop4.Minimum = num;
			this.NUpAutoStop.Name = "NUpAutoStop";
			global::System.Windows.Forms.Control nupAutoStop5 = this.NUpAutoStop;
			size = new global::System.Drawing.Size(74, 22);
			nupAutoStop5.Size = size;
			this.NUpAutoStop.TabIndex = 9;
			this.NUpAutoStop.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupAutoStop6 = this.NUpAutoStop;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				65536
			});
			nupAutoStop6.Value = num;
			this.NUpBinder.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpBinder.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupBinder = this.NUpBinder;
			location = new global::System.Drawing.Point(160, 15);
			nupBinder.Location = location;
			global::System.Windows.Forms.NumericUpDown nupBinder2 = this.NUpBinder;
			num = new decimal(new int[]
			{
				500,
				0,
				0,
				0
			});
			nupBinder2.Maximum = num;
			global::System.Windows.Forms.NumericUpDown nupBinder3 = this.NUpBinder;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupBinder3.Minimum = num;
			this.NUpBinder.Name = "NUpBinder";
			global::System.Windows.Forms.Control nupBinder4 = this.NUpBinder;
			size = new global::System.Drawing.Size(74, 22);
			nupBinder4.Size = size;
			this.NUpBinder.TabIndex = 7;
			this.NUpBinder.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupBinder5 = this.NUpBinder;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupBinder5.Value = num;
			this.Label7.AutoSize = true;
			this.Label7.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label13 = this.Label7;
			location = new global::System.Drawing.Point(12, 49);
			label13.Location = location;
			this.Label7.Name = "Label7";
			global::System.Windows.Forms.Control label14 = this.Label7;
			size = new global::System.Drawing.Size(124, 16);
			label14.Size = size;
			this.Label7.TabIndex = 6;
			this.Label7.Text = "Auto Stop Level (m)";
			this.Label6.AutoSize = true;
			this.Label6.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label15 = this.Label6;
			location = new global::System.Drawing.Point(12, 21);
			label15.Location = location;
			this.Label6.Name = "Label6";
			global::System.Windows.Forms.Control label16 = this.Label6;
			size = new global::System.Drawing.Size(88, 16);
			label16.Size = size;
			this.Label6.TabIndex = 4;
			this.Label6.Text = "Binder (kg/m)";
			this.NUpStigning.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpStigning.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupStigning = this.NUpStigning;
			location = new global::System.Drawing.Point(160, 79);
			nupStigning.Location = location;
			global::System.Windows.Forms.NumericUpDown nupStigning2 = this.NUpStigning;
			num = new decimal(new int[]
			{
				500,
				0,
				0,
				0
			});
			nupStigning2.Maximum = num;
			global::System.Windows.Forms.NumericUpDown nupStigning3 = this.NUpStigning;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupStigning3.Minimum = num;
			this.NUpStigning.Name = "NUpStigning";
			global::System.Windows.Forms.Control nupStigning4 = this.NUpStigning;
			size = new global::System.Drawing.Size(74, 22);
			nupStigning4.Size = size;
			this.NUpStigning.TabIndex = 15;
			this.NUpStigning.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupStigning5 = this.NUpStigning;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupStigning5.Value = num;
			this.Label9.AutoSize = true;
			this.Label9.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label17 = this.Label9;
			location = new global::System.Drawing.Point(12, 81);
			label17.Location = location;
			this.Label9.Name = "Label9";
			global::System.Windows.Forms.Control label18 = this.Label9;
			size = new global::System.Drawing.Size(130, 16);
			label18.Size = size;
			this.Label9.TabIndex = 10;
			this.Label9.Text = "Speed Up (mm/rpm)";
			this.GroupBox5.Controls.Add(this.NUpJoyRot);
			this.GroupBox5.Controls.Add(this.NUpJoyUppNer);
			this.GroupBox5.Controls.Add(this.Label5);
			this.GroupBox5.Controls.Add(this.Label8);
			global::System.Windows.Forms.Control groupBox7 = this.GroupBox5;
			location = new global::System.Drawing.Point(28, 158);
			groupBox7.Location = location;
			this.GroupBox5.Name = "GroupBox5";
			global::System.Windows.Forms.Control groupBox8 = this.GroupBox5;
			size = new global::System.Drawing.Size(303, 103);
			groupBox8.Size = size;
			this.GroupBox5.TabIndex = 1;
			this.GroupBox5.TabStop = false;
			this.GroupBox5.Text = "Joystick Limitations";
			this.NUpJoyRot.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpJoyRot.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupJoyRot = this.NUpJoyRot;
			location = new global::System.Drawing.Point(160, 55);
			nupJoyRot.Location = location;
			this.NUpJoyRot.Name = "NUpJoyRot";
			global::System.Windows.Forms.Control nupJoyRot2 = this.NUpJoyRot;
			size = new global::System.Drawing.Size(74, 22);
			nupJoyRot2.Size = size;
			this.NUpJoyRot.TabIndex = 11;
			this.NUpJoyRot.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupJoyRot3 = this.NUpJoyRot;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupJoyRot3.Value = num;
			this.NUpJoyUppNer.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpJoyUppNer.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupJoyUppNer = this.NUpJoyUppNer;
			location = new global::System.Drawing.Point(160, 27);
			nupJoyUppNer.Location = location;
			this.NUpJoyUppNer.Name = "NUpJoyUppNer";
			global::System.Windows.Forms.Control nupJoyUppNer2 = this.NUpJoyUppNer;
			size = new global::System.Drawing.Size(74, 22);
			nupJoyUppNer2.Size = size;
			this.NUpJoyUppNer.TabIndex = 9;
			this.NUpJoyUppNer.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupJoyUppNer3 = this.NUpJoyUppNer;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupJoyUppNer3.Value = num;
			this.Label5.AutoSize = true;
			this.Label5.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label19 = this.Label5;
			location = new global::System.Drawing.Point(12, 57);
			label19.Location = location;
			this.Label5.Name = "Label5";
			global::System.Windows.Forms.Control label20 = this.Label5;
			size = new global::System.Drawing.Size(81, 16);
			label20.Size = size;
			this.Label5.TabIndex = 10;
			this.Label5.Text = "Rotation (%)";
			this.Label8.AutoSize = true;
			this.Label8.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label21 = this.Label8;
			location = new global::System.Drawing.Point(12, 29);
			label21.Location = location;
			this.Label8.Name = "Label8";
			global::System.Windows.Forms.Control label22 = this.Label8;
			size = new global::System.Drawing.Size(95, 16);
			label22.Size = size;
			this.Label8.TabIndex = 8;
			this.Label8.Text = "Upp/Down (%)";
			this.GroupBox6.Controls.Add(this.NupDiameter);
			this.GroupBox6.Controls.Add(this.Label20);
			this.GroupBox6.Controls.Add(this.NUpRotMaxPelTillV);
			this.GroupBox6.Controls.Add(this.Label18);
			this.GroupBox6.Controls.Add(this.NUpÖnskadRotDrill);
			this.GroupBox6.Controls.Add(this.NUpMixFrånA);
			this.GroupBox6.Controls.Add(this.Label11);
			this.GroupBox6.Controls.Add(this.Label10);
			global::System.Windows.Forms.Control groupBox9 = this.GroupBox6;
			location = new global::System.Drawing.Point(28, 279);
			groupBox9.Location = location;
			this.GroupBox6.Name = "GroupBox6";
			global::System.Windows.Forms.Control groupBox10 = this.GroupBox6;
			size = new global::System.Drawing.Size(303, 191);
			groupBox10.Size = size;
			this.GroupBox6.TabIndex = 2;
			this.GroupBox6.TabStop = false;
			this.GroupBox6.Text = "Drill and Mixing Settings";
			this.NupDiameter.BackColor = global::System.Drawing.SystemColors.Control;
			this.NupDiameter.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupDiameter = this.NupDiameter;
			location = new global::System.Drawing.Point(160, 147);
			nupDiameter.Location = location;
			global::System.Windows.Forms.NumericUpDown nupDiameter2 = this.NupDiameter;
			num = new decimal(new int[]
			{
				1500,
				0,
				0,
				0
			});
			nupDiameter2.Maximum = num;
			global::System.Windows.Forms.NumericUpDown nupDiameter3 = this.NupDiameter;
			num = new decimal(new int[]
			{
				200,
				0,
				0,
				0
			});
			nupDiameter3.Minimum = num;
			this.NupDiameter.Name = "NupDiameter";
			global::System.Windows.Forms.Control nupDiameter4 = this.NupDiameter;
			size = new global::System.Drawing.Size(74, 22);
			nupDiameter4.Size = size;
			this.NupDiameter.TabIndex = 20;
			this.NupDiameter.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupDiameter5 = this.NupDiameter;
			num = new decimal(new int[]
			{
				800,
				0,
				0,
				0
			});
			nupDiameter5.Value = num;
			this.Label20.AutoSize = true;
			this.Label20.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label23 = this.Label20;
			location = new global::System.Drawing.Point(12, 149);
			label23.Location = location;
			this.Label20.Name = "Label20";
			global::System.Windows.Forms.Control label24 = this.Label20;
			size = new global::System.Drawing.Size(119, 16);
			label24.Size = size;
			this.Label20.TabIndex = 19;
			this.Label20.Text = "Col Diameter (mm)";
			this.NUpRotMaxPelTillV.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpRotMaxPelTillV.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupRotMaxPelTillV = this.NUpRotMaxPelTillV;
			location = new global::System.Drawing.Point(160, 84);
			nupRotMaxPelTillV.Location = location;
			this.NUpRotMaxPelTillV.Name = "NUpRotMaxPelTillV";
			global::System.Windows.Forms.Control nupRotMaxPelTillV2 = this.NUpRotMaxPelTillV;
			size = new global::System.Drawing.Size(74, 22);
			nupRotMaxPelTillV2.Size = size;
			this.NUpRotMaxPelTillV.TabIndex = 18;
			this.NUpRotMaxPelTillV.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupRotMaxPelTillV3 = this.NUpRotMaxPelTillV;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupRotMaxPelTillV3.Value = num;
			this.Label18.AutoSize = true;
			this.Label18.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label25 = this.Label18;
			location = new global::System.Drawing.Point(12, 86);
			label25.Location = location;
			this.Label18.Name = "Label18";
			global::System.Windows.Forms.Control label26 = this.Label18;
			size = new global::System.Drawing.Size(135, 16);
			label26.Size = size;
			this.Label18.TabIndex = 17;
			this.Label18.Text = "Rotation Drill max (%)";
			this.NUpÖnskadRotDrill.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpÖnskadRotDrill.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupÖnskadRotDrill = this.NUpÖnskadRotDrill;
			location = new global::System.Drawing.Point(160, 116);
			nupÖnskadRotDrill.Location = location;
			global::System.Windows.Forms.NumericUpDown nupÖnskadRotDrill2 = this.NUpÖnskadRotDrill;
			num = new decimal(new int[]
			{
				500,
				0,
				0,
				0
			});
			nupÖnskadRotDrill2.Maximum = num;
			global::System.Windows.Forms.NumericUpDown nupÖnskadRotDrill3 = this.NUpÖnskadRotDrill;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupÖnskadRotDrill3.Minimum = num;
			this.NUpÖnskadRotDrill.Name = "NUpÖnskadRotDrill";
			global::System.Windows.Forms.Control nupÖnskadRotDrill4 = this.NUpÖnskadRotDrill;
			size = new global::System.Drawing.Size(74, 22);
			nupÖnskadRotDrill4.Size = size;
			this.NUpÖnskadRotDrill.TabIndex = 16;
			this.NUpÖnskadRotDrill.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupÖnskadRotDrill5 = this.NUpÖnskadRotDrill;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupÖnskadRotDrill5.Value = num;
			this.NUpMixFrånA.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpMixFrånA.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupMixFrånA = this.NUpMixFrånA;
			location = new global::System.Drawing.Point(160, 27);
			nupMixFrånA.Location = location;
			this.NUpMixFrånA.Name = "NUpMixFrånA";
			global::System.Windows.Forms.Control nupMixFrånA2 = this.NUpMixFrånA;
			size = new global::System.Drawing.Size(74, 22);
			nupMixFrånA2.Size = size;
			this.NUpMixFrånA.TabIndex = 14;
			this.NUpMixFrånA.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupMixFrånA3 = this.NUpMixFrånA;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupMixFrånA3.Value = num;
			this.Label11.AutoSize = true;
			this.Label11.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label27 = this.Label11;
			location = new global::System.Drawing.Point(12, 118);
			label27.Location = location;
			this.Label11.Name = "Label11";
			global::System.Windows.Forms.Control label28 = this.Label11;
			size = new global::System.Drawing.Size(118, 16);
			label28.Size = size;
			this.Label11.TabIndex = 12;
			this.Label11.Text = "Rotation Drill (rpm)";
			this.Label10.AutoSize = true;
			this.Label10.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label29 = this.Label10;
			location = new global::System.Drawing.Point(12, 29);
			label29.Location = location;
			this.Label10.Name = "Label10";
			global::System.Windows.Forms.Control label30 = this.Label10;
			size = new global::System.Drawing.Size(149, 16);
			label30.Size = size;
			this.Label10.TabIndex = 8;
			this.Label10.Text = "Mixing From Tank A (%)";
			this.GroupBox7.Controls.Add(this.CheckStartUpMedel);
			this.GroupBox7.Controls.Add(this.CheckCellAuto);
			this.GroupBox7.Controls.Add(this.CheckMaxUpSpeed);
			global::System.Windows.Forms.Control groupBox11 = this.GroupBox7;
			location = new global::System.Drawing.Point(341, 279);
			groupBox11.Location = location;
			this.GroupBox7.Name = "GroupBox7";
			global::System.Windows.Forms.Control groupBox12 = this.GroupBox7;
			size = new global::System.Drawing.Size(303, 191);
			groupBox12.Size = size;
			this.GroupBox7.TabIndex = 3;
			this.GroupBox7.TabStop = false;
			this.GroupBox7.Text = "Column Auto Settings";
			this.CheckStartUpMedel.AutoSize = true;
			this.CheckStartUpMedel.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control checkStartUpMedel = this.CheckStartUpMedel;
			location = new global::System.Drawing.Point(40, 85);
			checkStartUpMedel.Location = location;
			this.CheckStartUpMedel.Name = "CheckStartUpMedel";
			global::System.Windows.Forms.Control checkStartUpMedel2 = this.CheckStartUpMedel;
			size = new global::System.Drawing.Size(171, 20);
			checkStartUpMedel2.Size = size;
			this.CheckStartUpMedel.TabIndex = 15;
			this.CheckStartUpMedel.Text = "Start Speed as Average";
			this.CheckStartUpMedel.UseVisualStyleBackColor = true;
			this.CheckCellAuto.AutoSize = true;
			this.CheckCellAuto.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control checkCellAuto = this.CheckCellAuto;
			location = new global::System.Drawing.Point(40, 57);
			checkCellAuto.Location = location;
			this.CheckCellAuto.Name = "CheckCellAuto";
			global::System.Windows.Forms.Control checkCellAuto2 = this.CheckCellAuto;
			size = new global::System.Drawing.Size(124, 20);
			checkCellAuto2.Size = size;
			this.CheckCellAuto.TabIndex = 14;
			this.CheckCellAuto.Text = "Cell Speed Auto";
			this.CheckCellAuto.UseVisualStyleBackColor = true;
			this.CheckMaxUpSpeed.AutoSize = true;
			this.CheckMaxUpSpeed.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control checkMaxUpSpeed = this.CheckMaxUpSpeed;
			location = new global::System.Drawing.Point(40, 29);
			checkMaxUpSpeed.Location = location;
			this.CheckMaxUpSpeed.Name = "CheckMaxUpSpeed";
			global::System.Windows.Forms.Control checkMaxUpSpeed2 = this.CheckMaxUpSpeed;
			size = new global::System.Drawing.Size(156, 20);
			checkMaxUpSpeed2.Size = size;
			this.CheckMaxUpSpeed.TabIndex = 13;
			this.CheckMaxUpSpeed.Text = "Maximized Up Speed";
			this.CheckMaxUpSpeed.UseVisualStyleBackColor = true;
			this.GroupBox8.Controls.Add(this.NUpRegFaktor);
			this.GroupBox8.Controls.Add(this.NUpEgetStartV);
			this.GroupBox8.Controls.Add(this.NUpAntalStartV);
			this.GroupBox8.Controls.Add(this.NUpMaxUppBits);
			this.GroupBox8.Controls.Add(this.NUpMinUppBits);
			this.GroupBox8.Controls.Add(this.TextSpare);
			this.GroupBox8.Controls.Add(this.Label15);
			this.GroupBox8.Controls.Add(this.Label16);
			this.GroupBox8.Controls.Add(this.Label17);
			this.GroupBox8.Controls.Add(this.Label12);
			this.GroupBox8.Controls.Add(this.Label13);
			this.GroupBox8.Controls.Add(this.Label14);
			global::System.Windows.Forms.Control groupBox13 = this.GroupBox8;
			location = new global::System.Drawing.Point(28, 476);
			groupBox13.Location = location;
			this.GroupBox8.Name = "GroupBox8";
			global::System.Windows.Forms.Control groupBox14 = this.GroupBox8;
			size = new global::System.Drawing.Size(616, 130);
			groupBox14.Size = size;
			this.GroupBox8.TabIndex = 4;
			this.GroupBox8.TabStop = false;
			this.GroupBox8.Text = "Column Auto Variables";
			this.NUpRegFaktor.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpRegFaktor.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupRegFaktor = this.NUpRegFaktor;
			location = new global::System.Drawing.Point(455, 52);
			nupRegFaktor.Location = location;
			global::System.Windows.Forms.NumericUpDown nupRegFaktor2 = this.NUpRegFaktor;
			num = new decimal(new int[]
			{
				2047,
				0,
				0,
				0
			});
			nupRegFaktor2.Maximum = num;
			this.NUpRegFaktor.Name = "NUpRegFaktor";
			global::System.Windows.Forms.Control nupRegFaktor3 = this.NUpRegFaktor;
			size = new global::System.Drawing.Size(74, 22);
			nupRegFaktor3.Size = size;
			this.NUpRegFaktor.TabIndex = 24;
			this.NUpRegFaktor.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupRegFaktor4 = this.NUpRegFaktor;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupRegFaktor4.Value = num;
			this.NUpEgetStartV.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpEgetStartV.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupEgetStartV = this.NUpEgetStartV;
			location = new global::System.Drawing.Point(455, 24);
			nupEgetStartV.Location = location;
			global::System.Windows.Forms.NumericUpDown nupEgetStartV2 = this.NUpEgetStartV;
			num = new decimal(new int[]
			{
				2047,
				0,
				0,
				0
			});
			nupEgetStartV2.Maximum = num;
			this.NUpEgetStartV.Name = "NUpEgetStartV";
			global::System.Windows.Forms.Control nupEgetStartV3 = this.NUpEgetStartV;
			size = new global::System.Drawing.Size(74, 22);
			nupEgetStartV3.Size = size;
			this.NUpEgetStartV.TabIndex = 23;
			this.NUpEgetStartV.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupEgetStartV4 = this.NUpEgetStartV;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupEgetStartV4.Value = num;
			this.NUpAntalStartV.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpAntalStartV.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupAntalStartV = this.NUpAntalStartV;
			location = new global::System.Drawing.Point(160, 83);
			nupAntalStartV.Location = location;
			global::System.Windows.Forms.NumericUpDown nupAntalStartV2 = this.NUpAntalStartV;
			num = new decimal(new int[]
			{
				3000,
				0,
				0,
				0
			});
			nupAntalStartV2.Maximum = num;
			this.NUpAntalStartV.Name = "NUpAntalStartV";
			global::System.Windows.Forms.Control nupAntalStartV3 = this.NUpAntalStartV;
			size = new global::System.Drawing.Size(74, 22);
			nupAntalStartV3.Size = size;
			this.NUpAntalStartV.TabIndex = 22;
			this.NUpAntalStartV.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupAntalStartV4 = this.NUpAntalStartV;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupAntalStartV4.Value = num;
			this.NUpMaxUppBits.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpMaxUppBits.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupMaxUppBits = this.NUpMaxUppBits;
			location = new global::System.Drawing.Point(160, 55);
			nupMaxUppBits.Location = location;
			global::System.Windows.Forms.NumericUpDown nupMaxUppBits2 = this.NUpMaxUppBits;
			num = new decimal(new int[]
			{
				2047,
				0,
				0,
				0
			});
			nupMaxUppBits2.Maximum = num;
			this.NUpMaxUppBits.Name = "NUpMaxUppBits";
			global::System.Windows.Forms.Control nupMaxUppBits3 = this.NUpMaxUppBits;
			size = new global::System.Drawing.Size(74, 22);
			nupMaxUppBits3.Size = size;
			this.NUpMaxUppBits.TabIndex = 21;
			this.NUpMaxUppBits.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupMaxUppBits4 = this.NUpMaxUppBits;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupMaxUppBits4.Value = num;
			this.NUpMinUppBits.BackColor = global::System.Drawing.SystemColors.Control;
			this.NUpMinUppBits.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control nupMinUppBits = this.NUpMinUppBits;
			location = new global::System.Drawing.Point(160, 27);
			nupMinUppBits.Location = location;
			global::System.Windows.Forms.NumericUpDown nupMinUppBits2 = this.NUpMinUppBits;
			num = new decimal(new int[]
			{
				2047,
				0,
				0,
				0
			});
			nupMinUppBits2.Maximum = num;
			this.NUpMinUppBits.Name = "NUpMinUppBits";
			global::System.Windows.Forms.Control nupMinUppBits3 = this.NUpMinUppBits;
			size = new global::System.Drawing.Size(74, 22);
			nupMinUppBits3.Size = size;
			this.NUpMinUppBits.TabIndex = 20;
			this.NUpMinUppBits.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown nupMinUppBits4 = this.NUpMinUppBits;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			nupMinUppBits4.Value = num;
			this.TextSpare.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control textSpare = this.TextSpare;
			location = new global::System.Drawing.Point(455, 79);
			textSpare.Location = location;
			this.TextSpare.Name = "TextSpare";
			this.TextSpare.ReadOnly = true;
			global::System.Windows.Forms.Control textSpare2 = this.TextSpare;
			size = new global::System.Drawing.Size(124, 22);
			textSpare2.Size = size;
			this.TextSpare.TabIndex = 19;
			this.Label15.AutoSize = true;
			this.Label15.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label31 = this.Label15;
			location = new global::System.Drawing.Point(307, 82);
			label31.Location = location;
			this.Label15.Name = "Label15";
			global::System.Windows.Forms.Control label32 = this.Label15;
			size = new global::System.Drawing.Size(45, 16);
			label32.Size = size;
			this.Label15.TabIndex = 18;
			this.Label15.Text = "Spare";
			this.Label16.AutoSize = true;
			this.Label16.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label33 = this.Label16;
			location = new global::System.Drawing.Point(307, 54);
			label33.Location = location;
			this.Label16.Name = "Label16";
			global::System.Windows.Forms.Control label34 = this.Label16;
			size = new global::System.Drawing.Size(109, 16);
			label34.Size = size;
			this.Label16.TabIndex = 16;
			this.Label16.Text = "Auto Change (Int)";
			this.Label17.AutoSize = true;
			this.Label17.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label35 = this.Label17;
			location = new global::System.Drawing.Point(307, 26);
			label35.Location = location;
			this.Label17.Name = "Label17";
			global::System.Windows.Forms.Control label36 = this.Label17;
			size = new global::System.Drawing.Size(140, 16);
			label36.Size = size;
			this.Label17.TabIndex = 14;
			this.Label17.Text = "Own Start Speed (bits)";
			this.Label12.AutoSize = true;
			this.Label12.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label37 = this.Label12;
			location = new global::System.Drawing.Point(12, 85);
			label37.Location = location;
			this.Label12.Name = "Label12";
			global::System.Windows.Forms.Control label38 = this.Label12;
			size = new global::System.Drawing.Size(117, 16);
			label38.Size = size;
			this.Label12.TabIndex = 12;
			this.Label12.Text = "Nos of Starts (pcs)";
			this.Label13.AutoSize = true;
			this.Label13.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label39 = this.Label13;
			location = new global::System.Drawing.Point(12, 57);
			label39.Location = location;
			this.Label13.Name = "Label13";
			global::System.Windows.Forms.Control label40 = this.Label13;
			size = new global::System.Drawing.Size(133, 16);
			label40.Size = size;
			this.Label13.TabIndex = 10;
			this.Label13.Text = "Max. Speed Up (bits)";
			this.Label14.AutoSize = true;
			this.Label14.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label41 = this.Label14;
			location = new global::System.Drawing.Point(12, 29);
			label41.Location = location;
			this.Label14.Name = "Label14";
			global::System.Windows.Forms.Control label42 = this.Label14;
			size = new global::System.Drawing.Size(129, 16);
			label42.Size = size;
			this.Label14.TabIndex = 8;
			this.Label14.Text = "Min. Speed Up (bits)";
			global::System.Windows.Forms.Control button = this.Button1;
			location = new global::System.Drawing.Point(817, 437);
			button.Location = location;
			this.Button1.Name = "Button1";
			global::System.Windows.Forms.Control button2 = this.Button1;
			size = new global::System.Drawing.Size(116, 38);
			button2.Size = size;
			this.Button1.TabIndex = 5;
			this.Button1.Text = "Save changes";
			this.Button1.UseVisualStyleBackColor = true;
			global::System.Windows.Forms.Control button3 = this.Button2;
			location = new global::System.Drawing.Point(817, 496);
			button3.Location = location;
			this.Button2.Name = "Button2";
			global::System.Windows.Forms.Control button4 = this.Button2;
			size = new global::System.Drawing.Size(116, 38);
			button4.Size = size;
			this.Button2.TabIndex = 6;
			this.Button2.Text = "Close";
			this.Button2.UseVisualStyleBackColor = true;
			this.tmrÄndringsKoll.Interval = 1000;
			this.Label19.AutoSize = true;
			global::System.Windows.Forms.Control label43 = this.Label19;
			location = new global::System.Drawing.Point(767, 185);
			label43.Location = location;
			this.Label19.Name = "Label19";
			global::System.Windows.Forms.Control label44 = this.Label19;
			size = new global::System.Drawing.Size(45, 13);
			label44.Size = size;
			this.Label19.TabIndex = 7;
			this.Label19.Text = "Label19";
			this.Label19.Visible = false;
			this.GroupBox1.Controls.Add(this.CheckTankBoff);
			this.GroupBox1.Controls.Add(this.CheckTankAoff);
			global::System.Windows.Forms.Control groupBox15 = this.GroupBox1;
			location = new global::System.Drawing.Point(344, 158);
			groupBox15.Location = location;
			this.GroupBox1.Name = "GroupBox1";
			global::System.Windows.Forms.Control groupBox16 = this.GroupBox1;
			size = new global::System.Drawing.Size(300, 103);
			groupBox16.Size = size;
			this.GroupBox1.TabIndex = 8;
			this.GroupBox1.TabStop = false;
			this.GroupBox1.Text = "Stop use this weight information (Hardware problem)";
			this.CheckTankBoff.AutoSize = true;
			this.CheckTankBoff.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control checkTankBoff = this.CheckTankBoff;
			location = new global::System.Drawing.Point(37, 53);
			checkTankBoff.Location = location;
			this.CheckTankBoff.Name = "CheckTankBoff";
			global::System.Windows.Forms.Control checkTankBoff2 = this.CheckTankBoff;
			size = new global::System.Drawing.Size(126, 20);
			checkTankBoff2.Size = size;
			this.CheckTankBoff.TabIndex = 16;
			this.CheckTankBoff.Text = "Stop use Tank B";
			this.CheckTankBoff.UseVisualStyleBackColor = true;
			this.CheckTankAoff.AutoSize = true;
			this.CheckTankAoff.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control checkTankAoff = this.CheckTankAoff;
			location = new global::System.Drawing.Point(37, 27);
			checkTankAoff.Location = location;
			this.CheckTankAoff.Name = "CheckTankAoff";
			global::System.Windows.Forms.Control checkTankAoff2 = this.CheckTankAoff;
			size = new global::System.Drawing.Size(126, 20);
			checkTankAoff2.Size = size;
			this.CheckTankAoff.TabIndex = 15;
			this.CheckTankAoff.Text = "Stop use Tank A";
			this.CheckTankAoff.UseVisualStyleBackColor = true;
			global::System.Drawing.SizeF autoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			size = new global::System.Drawing.Size(991, 626);
			this.ClientSize = size;
			this.Controls.Add(this.GroupBox1);
			this.Controls.Add(this.Label19);
			this.Controls.Add(this.GroupBox2);
			this.Controls.Add(this.GroupBox3);
			this.Controls.Add(this.GroupBox4);
			this.Controls.Add(this.Button2);
			this.Controls.Add(this.Button1);
			this.Controls.Add(this.GroupBox8);
			this.Controls.Add(this.GroupBox7);
			this.Controls.Add(this.GroupBox6);
			this.Controls.Add(this.GroupBox5);
			this.Name = "FormSettings";
			this.Text = "FormSettings";
			this.GroupBox4.ResumeLayout(false);
			this.GroupBox4.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NUpStigBotten).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpBottDjup).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpBinderBott).EndInit();
			this.GroupBox3.ResumeLayout(false);
			this.GroupBox3.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NUpStigTopp).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpTopDjup).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpBinderTop).EndInit();
			this.GroupBox2.ResumeLayout(false);
			this.GroupBox2.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NUpAutoStop).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpBinder).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpStigning).EndInit();
			this.GroupBox5.ResumeLayout(false);
			this.GroupBox5.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NUpJoyRot).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpJoyUppNer).EndInit();
			this.GroupBox6.ResumeLayout(false);
			this.GroupBox6.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NupDiameter).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpRotMaxPelTillV).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpÖnskadRotDrill).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpMixFrånA).EndInit();
			this.GroupBox7.ResumeLayout(false);
			this.GroupBox7.PerformLayout();
			this.GroupBox8.ResumeLayout(false);
			this.GroupBox8.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NUpRegFaktor).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpEgetStartV).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpAntalStartV).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpMaxUppBits).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NUpMinUppBits).EndInit();
			this.GroupBox1.ResumeLayout(false);
			this.GroupBox1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x040000D3 RID: 211
		private global::System.ComponentModel.IContainer components;
	}
}
