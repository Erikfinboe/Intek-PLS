﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.4.0.0")]
[assembly: AssemblyProduct("winKCdrill")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("Copyright © SKANSKA 2008")]
[assembly: AssemblyCompany("SKANSKA")]
[assembly: AssemblyDescription("Lime Column software for KC rigs")]
[assembly: AssemblyTitle("winKCdrill")]
[assembly: AssemblyFileVersion("1.4.0.0")]
[assembly: Guid("e83189f1-1593-4343-aa11-0d78c4ef5d9a")]
[assembly: ComVisible(false)]
