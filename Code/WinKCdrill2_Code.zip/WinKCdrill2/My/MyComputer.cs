﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using Microsoft.VisualBasic.Devices;

namespace winKCdrill2.My
{
	// Token: 0x02000003 RID: 3
	[EditorBrowsable(EditorBrowsableState.Never)]
	[GeneratedCode("MyTemplate", "8.0.0.0")]
	internal class MyComputer : Computer
	{
		// Token: 0x06000005 RID: 5 RVA: 0x000328F4 File Offset: 0x00030CF4
		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerHidden]
		public MyComputer()
		{
		}
	}
}
