﻿namespace winKCdrill2
{
	// Token: 0x0200000E RID: 14
	public partial class frmTestaApp : global::System.Windows.Forms.Form
	{
		// Token: 0x06000224 RID: 548 RVA: 0x0002C88C File Offset: 0x0002AC8C
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000293 RID: 659 RVA: 0x0002CF8C File Offset: 0x0002B38C
		[global::System.Diagnostics.DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			this.GroupBox1 = new global::System.Windows.Forms.GroupBox();
			this.GroupBox5 = new global::System.Windows.Forms.GroupBox();
			this.CheckBox7 = new global::System.Windows.Forms.CheckBox();
			this.CheckBox8 = new global::System.Windows.Forms.CheckBox();
			this.GroupBox4 = new global::System.Windows.Forms.GroupBox();
			this.CheckBox5 = new global::System.Windows.Forms.CheckBox();
			this.CheckBox6 = new global::System.Windows.Forms.CheckBox();
			this.GroupBox3 = new global::System.Windows.Forms.GroupBox();
			this.CheckBox4 = new global::System.Windows.Forms.CheckBox();
			this.CheckBox3 = new global::System.Windows.Forms.CheckBox();
			this.GroupBox2 = new global::System.Windows.Forms.GroupBox();
			this.CheckBox2 = new global::System.Windows.Forms.CheckBox();
			this.CheckBox1 = new global::System.Windows.Forms.CheckBox();
			this.Label3 = new global::System.Windows.Forms.Label();
			this.NumericUpDown3 = new global::System.Windows.Forms.NumericUpDown();
			this.Label2 = new global::System.Windows.Forms.Label();
			this.NumericUpDown2 = new global::System.Windows.Forms.NumericUpDown();
			this.Label1 = new global::System.Windows.Forms.Label();
			this.NumericUpDown1 = new global::System.Windows.Forms.NumericUpDown();
			this.Timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.GroupBox6 = new global::System.Windows.Forms.GroupBox();
			this.GroupBox7 = new global::System.Windows.Forms.GroupBox();
			this.CheckBox9 = new global::System.Windows.Forms.CheckBox();
			this.CheckBox10 = new global::System.Windows.Forms.CheckBox();
			this.GroupBox8 = new global::System.Windows.Forms.GroupBox();
			this.CheckBox11 = new global::System.Windows.Forms.CheckBox();
			this.CheckBox12 = new global::System.Windows.Forms.CheckBox();
			this.GroupBox9 = new global::System.Windows.Forms.GroupBox();
			this.CheckBox13 = new global::System.Windows.Forms.CheckBox();
			this.CheckBox14 = new global::System.Windows.Forms.CheckBox();
			this.GroupBox10 = new global::System.Windows.Forms.GroupBox();
			this.CheckBox15 = new global::System.Windows.Forms.CheckBox();
			this.CheckBox16 = new global::System.Windows.Forms.CheckBox();
			this.Label4 = new global::System.Windows.Forms.Label();
			this.NumericUpDown4 = new global::System.Windows.Forms.NumericUpDown();
			this.Label5 = new global::System.Windows.Forms.Label();
			this.NumericUpDown5 = new global::System.Windows.Forms.NumericUpDown();
			this.Label6 = new global::System.Windows.Forms.Label();
			this.NumericUpDown6 = new global::System.Windows.Forms.NumericUpDown();
			this.GroupBox11 = new global::System.Windows.Forms.GroupBox();
			this.Label9 = new global::System.Windows.Forms.Label();
			this.NumericUpDown9 = new global::System.Windows.Forms.NumericUpDown();
			this.Label8 = new global::System.Windows.Forms.Label();
			this.NumericUpDown8 = new global::System.Windows.Forms.NumericUpDown();
			this.Label7 = new global::System.Windows.Forms.Label();
			this.NumericUpDown7 = new global::System.Windows.Forms.NumericUpDown();
			this.GroupBox12 = new global::System.Windows.Forms.GroupBox();
			this.Label13 = new global::System.Windows.Forms.Label();
			this.NumericUpDown13 = new global::System.Windows.Forms.NumericUpDown();
			this.Label12 = new global::System.Windows.Forms.Label();
			this.NumericUpDown12 = new global::System.Windows.Forms.NumericUpDown();
			this.Label11 = new global::System.Windows.Forms.Label();
			this.NumericUpDown11 = new global::System.Windows.Forms.NumericUpDown();
			this.Label10 = new global::System.Windows.Forms.Label();
			this.NumericUpDown10 = new global::System.Windows.Forms.NumericUpDown();
			this.GroupBox1.SuspendLayout();
			this.GroupBox5.SuspendLayout();
			this.GroupBox4.SuspendLayout();
			this.GroupBox3.SuspendLayout();
			this.GroupBox2.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown3).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown2).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown1).BeginInit();
			this.GroupBox6.SuspendLayout();
			this.GroupBox7.SuspendLayout();
			this.GroupBox8.SuspendLayout();
			this.GroupBox9.SuspendLayout();
			this.GroupBox10.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown4).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown5).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown6).BeginInit();
			this.GroupBox11.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown9).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown8).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown7).BeginInit();
			this.GroupBox12.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown13).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown12).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown11).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown10).BeginInit();
			this.SuspendLayout();
			this.GroupBox1.Controls.Add(this.GroupBox5);
			this.GroupBox1.Controls.Add(this.GroupBox4);
			this.GroupBox1.Controls.Add(this.GroupBox3);
			this.GroupBox1.Controls.Add(this.GroupBox2);
			this.GroupBox1.Controls.Add(this.Label3);
			this.GroupBox1.Controls.Add(this.NumericUpDown3);
			this.GroupBox1.Controls.Add(this.Label2);
			this.GroupBox1.Controls.Add(this.NumericUpDown2);
			this.GroupBox1.Controls.Add(this.Label1);
			this.GroupBox1.Controls.Add(this.NumericUpDown1);
			global::System.Windows.Forms.Control groupBox = this.GroupBox1;
			global::System.Drawing.Point location = new global::System.Drawing.Point(8, 8);
			groupBox.Location = location;
			this.GroupBox1.Name = "GroupBox1";
			global::System.Windows.Forms.Control groupBox2 = this.GroupBox1;
			global::System.Drawing.Size size = new global::System.Drawing.Size(200, 296);
			groupBox2.Size = size;
			this.GroupBox1.TabIndex = 0;
			this.GroupBox1.TabStop = false;
			this.GroupBox1.Text = "Tank A";
			this.GroupBox5.Controls.Add(this.CheckBox7);
			this.GroupBox5.Controls.Add(this.CheckBox8);
			global::System.Windows.Forms.Control groupBox3 = this.GroupBox5;
			location = new global::System.Drawing.Point(8, 240);
			groupBox3.Location = location;
			this.GroupBox5.Name = "GroupBox5";
			global::System.Windows.Forms.Control groupBox4 = this.GroupBox5;
			size = new global::System.Drawing.Size(184, 40);
			groupBox4.Size = size;
			this.GroupBox5.TabIndex = 9;
			this.GroupBox5.TabStop = false;
			this.GroupBox5.Text = "Valve Release";
			global::System.Windows.Forms.Control checkBox = this.CheckBox7;
			location = new global::System.Drawing.Point(104, 16);
			checkBox.Location = location;
			this.CheckBox7.Name = "CheckBox7";
			global::System.Windows.Forms.Control checkBox2 = this.CheckBox7;
			size = new global::System.Drawing.Size(64, 16);
			checkBox2.Size = size;
			this.CheckBox7.TabIndex = 7;
			this.CheckBox7.Text = "Open";
			global::System.Windows.Forms.Control checkBox3 = this.CheckBox8;
			location = new global::System.Drawing.Point(16, 16);
			checkBox3.Location = location;
			this.CheckBox8.Name = "CheckBox8";
			global::System.Windows.Forms.Control checkBox4 = this.CheckBox8;
			size = new global::System.Drawing.Size(72, 16);
			checkBox4.Size = size;
			this.CheckBox8.TabIndex = 6;
			this.CheckBox8.Text = "Closed";
			this.GroupBox4.Controls.Add(this.CheckBox5);
			this.GroupBox4.Controls.Add(this.CheckBox6);
			global::System.Windows.Forms.Control groupBox5 = this.GroupBox4;
			location = new global::System.Drawing.Point(8, 200);
			groupBox5.Location = location;
			this.GroupBox4.Name = "GroupBox4";
			global::System.Windows.Forms.Control groupBox6 = this.GroupBox4;
			size = new global::System.Drawing.Size(184, 40);
			groupBox6.Size = size;
			this.GroupBox4.TabIndex = 8;
			this.GroupBox4.TabStop = false;
			this.GroupBox4.Text = "Valve Binder out to ground";
			global::System.Windows.Forms.Control checkBox5 = this.CheckBox5;
			location = new global::System.Drawing.Point(104, 16);
			checkBox5.Location = location;
			this.CheckBox5.Name = "CheckBox5";
			global::System.Windows.Forms.Control checkBox6 = this.CheckBox5;
			size = new global::System.Drawing.Size(64, 16);
			checkBox6.Size = size;
			this.CheckBox5.TabIndex = 7;
			this.CheckBox5.Text = "Open";
			global::System.Windows.Forms.Control checkBox7 = this.CheckBox6;
			location = new global::System.Drawing.Point(16, 16);
			checkBox7.Location = location;
			this.CheckBox6.Name = "CheckBox6";
			global::System.Windows.Forms.Control checkBox8 = this.CheckBox6;
			size = new global::System.Drawing.Size(72, 16);
			checkBox8.Size = size;
			this.CheckBox6.TabIndex = 6;
			this.CheckBox6.Text = "Closed";
			this.GroupBox3.Controls.Add(this.CheckBox4);
			this.GroupBox3.Controls.Add(this.CheckBox3);
			global::System.Windows.Forms.Control groupBox7 = this.GroupBox3;
			location = new global::System.Drawing.Point(8, 160);
			groupBox7.Location = location;
			this.GroupBox3.Name = "GroupBox3";
			global::System.Windows.Forms.Control groupBox8 = this.GroupBox3;
			size = new global::System.Drawing.Size(184, 40);
			groupBox8.Size = size;
			this.GroupBox3.TabIndex = 7;
			this.GroupBox3.TabStop = false;
			this.GroupBox3.Text = "Valve Air to Filter";
			global::System.Windows.Forms.Control checkBox9 = this.CheckBox4;
			location = new global::System.Drawing.Point(16, 16);
			checkBox9.Location = location;
			this.CheckBox4.Name = "CheckBox4";
			global::System.Windows.Forms.Control checkBox10 = this.CheckBox4;
			size = new global::System.Drawing.Size(72, 16);
			checkBox10.Size = size;
			this.CheckBox4.TabIndex = 6;
			this.CheckBox4.Text = "Closed";
			global::System.Windows.Forms.Control checkBox11 = this.CheckBox3;
			location = new global::System.Drawing.Point(104, 16);
			checkBox11.Location = location;
			this.CheckBox3.Name = "CheckBox3";
			global::System.Windows.Forms.Control checkBox12 = this.CheckBox3;
			size = new global::System.Drawing.Size(64, 16);
			checkBox12.Size = size;
			this.CheckBox3.TabIndex = 7;
			this.CheckBox3.Text = "Open";
			this.GroupBox2.Controls.Add(this.CheckBox2);
			this.GroupBox2.Controls.Add(this.CheckBox1);
			global::System.Windows.Forms.Control groupBox9 = this.GroupBox2;
			location = new global::System.Drawing.Point(8, 120);
			groupBox9.Location = location;
			this.GroupBox2.Name = "GroupBox2";
			global::System.Windows.Forms.Control groupBox10 = this.GroupBox2;
			size = new global::System.Drawing.Size(184, 40);
			groupBox10.Size = size;
			this.GroupBox2.TabIndex = 6;
			this.GroupBox2.TabStop = false;
			this.GroupBox2.Text = "Valve Binder Fill";
			global::System.Windows.Forms.Control checkBox13 = this.CheckBox2;
			location = new global::System.Drawing.Point(104, 16);
			checkBox13.Location = location;
			this.CheckBox2.Name = "CheckBox2";
			global::System.Windows.Forms.Control checkBox14 = this.CheckBox2;
			size = new global::System.Drawing.Size(64, 16);
			checkBox14.Size = size;
			this.CheckBox2.TabIndex = 7;
			this.CheckBox2.Text = "Open";
			global::System.Windows.Forms.Control checkBox15 = this.CheckBox1;
			location = new global::System.Drawing.Point(16, 16);
			checkBox15.Location = location;
			this.CheckBox1.Name = "CheckBox1";
			global::System.Windows.Forms.Control checkBox16 = this.CheckBox1;
			size = new global::System.Drawing.Size(72, 16);
			checkBox16.Size = size;
			this.CheckBox1.TabIndex = 6;
			this.CheckBox1.Text = "Closed";
			this.Label3.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label = this.Label3;
			location = new global::System.Drawing.Point(32, 88);
			label.Location = location;
			this.Label3.Name = "Label3";
			global::System.Windows.Forms.Control label2 = this.Label3;
			size = new global::System.Drawing.Size(72, 16);
			label2.Size = size;
			this.Label3.TabIndex = 5;
			this.Label3.Text = "F. speed";
			this.Label3.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			global::System.Windows.Forms.Control numericUpDown = this.NumericUpDown3;
			location = new global::System.Drawing.Point(120, 88);
			numericUpDown.Location = location;
			global::System.Windows.Forms.NumericUpDown numericUpDown2 = this.NumericUpDown3;
			decimal num = new decimal(new int[]
			{
				40,
				0,
				0,
				0
			});
			numericUpDown2.Maximum = num;
			this.NumericUpDown3.Name = "NumericUpDown3";
			global::System.Windows.Forms.Control numericUpDown3 = this.NumericUpDown3;
			size = new global::System.Drawing.Size(72, 20);
			numericUpDown3.Size = size;
			this.NumericUpDown3.TabIndex = 4;
			this.NumericUpDown3.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.Label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label3 = this.Label2;
			location = new global::System.Drawing.Point(32, 56);
			label3.Location = location;
			this.Label2.Name = "Label2";
			global::System.Windows.Forms.Control label4 = this.Label2;
			size = new global::System.Drawing.Size(72, 16);
			label4.Size = size;
			this.Label2.TabIndex = 3;
			this.Label2.Text = "Pressure";
			this.Label2.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.NumericUpDown2.DecimalPlaces = 2;
			global::System.Windows.Forms.NumericUpDown numericUpDown4 = this.NumericUpDown2;
			num = new decimal(new int[]
			{
				2,
				0,
				0,
				131072
			});
			numericUpDown4.Increment = num;
			global::System.Windows.Forms.Control numericUpDown5 = this.NumericUpDown2;
			location = new global::System.Drawing.Point(120, 56);
			numericUpDown5.Location = location;
			global::System.Windows.Forms.NumericUpDown numericUpDown6 = this.NumericUpDown2;
			num = new decimal(new int[]
			{
				10,
				0,
				0,
				0
			});
			numericUpDown6.Maximum = num;
			global::System.Windows.Forms.NumericUpDown numericUpDown7 = this.NumericUpDown2;
			num = new decimal(new int[]
			{
				1,
				0,
				0,
				int.MinValue
			});
			numericUpDown7.Minimum = num;
			this.NumericUpDown2.Name = "NumericUpDown2";
			global::System.Windows.Forms.Control numericUpDown8 = this.NumericUpDown2;
			size = new global::System.Drawing.Size(72, 20);
			numericUpDown8.Size = size;
			this.NumericUpDown2.TabIndex = 2;
			this.NumericUpDown2.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.Label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label5 = this.Label1;
			location = new global::System.Drawing.Point(32, 24);
			label5.Location = location;
			this.Label1.Name = "Label1";
			global::System.Windows.Forms.Control label6 = this.Label1;
			size = new global::System.Drawing.Size(72, 16);
			label6.Size = size;
			this.Label1.TabIndex = 1;
			this.Label1.Text = "Weight";
			this.Label1.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			global::System.Windows.Forms.Control numericUpDown9 = this.NumericUpDown1;
			location = new global::System.Drawing.Point(120, 24);
			numericUpDown9.Location = location;
			global::System.Windows.Forms.NumericUpDown numericUpDown10 = this.NumericUpDown1;
			num = new decimal(new int[]
			{
				4500,
				0,
				0,
				0
			});
			numericUpDown10.Maximum = num;
			global::System.Windows.Forms.NumericUpDown numericUpDown11 = this.NumericUpDown1;
			num = new decimal(new int[]
			{
				500,
				0,
				0,
				int.MinValue
			});
			numericUpDown11.Minimum = num;
			this.NumericUpDown1.Name = "NumericUpDown1";
			global::System.Windows.Forms.Control numericUpDown12 = this.NumericUpDown1;
			size = new global::System.Drawing.Size(72, 20);
			numericUpDown12.Size = size;
			this.NumericUpDown1.TabIndex = 0;
			this.NumericUpDown1.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.GroupBox6.Controls.Add(this.GroupBox7);
			this.GroupBox6.Controls.Add(this.GroupBox8);
			this.GroupBox6.Controls.Add(this.GroupBox9);
			this.GroupBox6.Controls.Add(this.GroupBox10);
			this.GroupBox6.Controls.Add(this.Label4);
			this.GroupBox6.Controls.Add(this.NumericUpDown4);
			this.GroupBox6.Controls.Add(this.Label5);
			this.GroupBox6.Controls.Add(this.NumericUpDown5);
			this.GroupBox6.Controls.Add(this.Label6);
			this.GroupBox6.Controls.Add(this.NumericUpDown6);
			global::System.Windows.Forms.Control groupBox11 = this.GroupBox6;
			location = new global::System.Drawing.Point(224, 8);
			groupBox11.Location = location;
			this.GroupBox6.Name = "GroupBox6";
			global::System.Windows.Forms.Control groupBox12 = this.GroupBox6;
			size = new global::System.Drawing.Size(208, 296);
			groupBox12.Size = size;
			this.GroupBox6.TabIndex = 1;
			this.GroupBox6.TabStop = false;
			this.GroupBox6.Text = "Tank B";
			this.GroupBox7.Controls.Add(this.CheckBox9);
			this.GroupBox7.Controls.Add(this.CheckBox10);
			global::System.Windows.Forms.Control groupBox13 = this.GroupBox7;
			location = new global::System.Drawing.Point(8, 248);
			groupBox13.Location = location;
			this.GroupBox7.Name = "GroupBox7";
			global::System.Windows.Forms.Control groupBox14 = this.GroupBox7;
			size = new global::System.Drawing.Size(184, 40);
			groupBox14.Size = size;
			this.GroupBox7.TabIndex = 9;
			this.GroupBox7.TabStop = false;
			this.GroupBox7.Text = "Valve Release";
			global::System.Windows.Forms.Control checkBox17 = this.CheckBox9;
			location = new global::System.Drawing.Point(104, 16);
			checkBox17.Location = location;
			this.CheckBox9.Name = "CheckBox9";
			global::System.Windows.Forms.Control checkBox18 = this.CheckBox9;
			size = new global::System.Drawing.Size(64, 16);
			checkBox18.Size = size;
			this.CheckBox9.TabIndex = 7;
			this.CheckBox9.Text = "Open";
			global::System.Windows.Forms.Control checkBox19 = this.CheckBox10;
			location = new global::System.Drawing.Point(16, 16);
			checkBox19.Location = location;
			this.CheckBox10.Name = "CheckBox10";
			global::System.Windows.Forms.Control checkBox20 = this.CheckBox10;
			size = new global::System.Drawing.Size(72, 16);
			checkBox20.Size = size;
			this.CheckBox10.TabIndex = 6;
			this.CheckBox10.Text = "Closed";
			this.GroupBox8.Controls.Add(this.CheckBox11);
			this.GroupBox8.Controls.Add(this.CheckBox12);
			global::System.Windows.Forms.Control groupBox15 = this.GroupBox8;
			location = new global::System.Drawing.Point(8, 200);
			groupBox15.Location = location;
			this.GroupBox8.Name = "GroupBox8";
			global::System.Windows.Forms.Control groupBox16 = this.GroupBox8;
			size = new global::System.Drawing.Size(184, 40);
			groupBox16.Size = size;
			this.GroupBox8.TabIndex = 8;
			this.GroupBox8.TabStop = false;
			this.GroupBox8.Text = "Valve Binder out to ground";
			global::System.Windows.Forms.Control checkBox21 = this.CheckBox11;
			location = new global::System.Drawing.Point(104, 16);
			checkBox21.Location = location;
			this.CheckBox11.Name = "CheckBox11";
			global::System.Windows.Forms.Control checkBox22 = this.CheckBox11;
			size = new global::System.Drawing.Size(64, 16);
			checkBox22.Size = size;
			this.CheckBox11.TabIndex = 7;
			this.CheckBox11.Text = "Open";
			global::System.Windows.Forms.Control checkBox23 = this.CheckBox12;
			location = new global::System.Drawing.Point(16, 16);
			checkBox23.Location = location;
			this.CheckBox12.Name = "CheckBox12";
			global::System.Windows.Forms.Control checkBox24 = this.CheckBox12;
			size = new global::System.Drawing.Size(72, 16);
			checkBox24.Size = size;
			this.CheckBox12.TabIndex = 6;
			this.CheckBox12.Text = "Closed";
			this.GroupBox9.Controls.Add(this.CheckBox13);
			this.GroupBox9.Controls.Add(this.CheckBox14);
			global::System.Windows.Forms.Control groupBox17 = this.GroupBox9;
			location = new global::System.Drawing.Point(8, 160);
			groupBox17.Location = location;
			this.GroupBox9.Name = "GroupBox9";
			global::System.Windows.Forms.Control groupBox18 = this.GroupBox9;
			size = new global::System.Drawing.Size(184, 40);
			groupBox18.Size = size;
			this.GroupBox9.TabIndex = 7;
			this.GroupBox9.TabStop = false;
			this.GroupBox9.Text = "Valve Air to Filter";
			global::System.Windows.Forms.Control checkBox25 = this.CheckBox13;
			location = new global::System.Drawing.Point(16, 16);
			checkBox25.Location = location;
			this.CheckBox13.Name = "CheckBox13";
			global::System.Windows.Forms.Control checkBox26 = this.CheckBox13;
			size = new global::System.Drawing.Size(72, 16);
			checkBox26.Size = size;
			this.CheckBox13.TabIndex = 6;
			this.CheckBox13.Text = "Closed";
			global::System.Windows.Forms.Control checkBox27 = this.CheckBox14;
			location = new global::System.Drawing.Point(104, 16);
			checkBox27.Location = location;
			this.CheckBox14.Name = "CheckBox14";
			global::System.Windows.Forms.Control checkBox28 = this.CheckBox14;
			size = new global::System.Drawing.Size(64, 16);
			checkBox28.Size = size;
			this.CheckBox14.TabIndex = 7;
			this.CheckBox14.Text = "Open";
			this.GroupBox10.Controls.Add(this.CheckBox15);
			this.GroupBox10.Controls.Add(this.CheckBox16);
			global::System.Windows.Forms.Control groupBox19 = this.GroupBox10;
			location = new global::System.Drawing.Point(8, 120);
			groupBox19.Location = location;
			this.GroupBox10.Name = "GroupBox10";
			global::System.Windows.Forms.Control groupBox20 = this.GroupBox10;
			size = new global::System.Drawing.Size(184, 40);
			groupBox20.Size = size;
			this.GroupBox10.TabIndex = 6;
			this.GroupBox10.TabStop = false;
			this.GroupBox10.Text = "Valve Binder Fill";
			global::System.Windows.Forms.Control checkBox29 = this.CheckBox15;
			location = new global::System.Drawing.Point(104, 16);
			checkBox29.Location = location;
			this.CheckBox15.Name = "CheckBox15";
			global::System.Windows.Forms.Control checkBox30 = this.CheckBox15;
			size = new global::System.Drawing.Size(64, 16);
			checkBox30.Size = size;
			this.CheckBox15.TabIndex = 7;
			this.CheckBox15.Text = "Open";
			global::System.Windows.Forms.Control checkBox31 = this.CheckBox16;
			location = new global::System.Drawing.Point(16, 16);
			checkBox31.Location = location;
			this.CheckBox16.Name = "CheckBox16";
			global::System.Windows.Forms.Control checkBox32 = this.CheckBox16;
			size = new global::System.Drawing.Size(72, 16);
			checkBox32.Size = size;
			this.CheckBox16.TabIndex = 6;
			this.CheckBox16.Text = "Closed";
			this.Label4.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label7 = this.Label4;
			location = new global::System.Drawing.Point(32, 88);
			label7.Location = location;
			this.Label4.Name = "Label4";
			global::System.Windows.Forms.Control label8 = this.Label4;
			size = new global::System.Drawing.Size(72, 16);
			label8.Size = size;
			this.Label4.TabIndex = 5;
			this.Label4.Text = "F. speed";
			this.Label4.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			global::System.Windows.Forms.Control numericUpDown13 = this.NumericUpDown4;
			location = new global::System.Drawing.Point(120, 88);
			numericUpDown13.Location = location;
			global::System.Windows.Forms.NumericUpDown numericUpDown14 = this.NumericUpDown4;
			num = new decimal(new int[]
			{
				40,
				0,
				0,
				0
			});
			numericUpDown14.Maximum = num;
			this.NumericUpDown4.Name = "NumericUpDown4";
			global::System.Windows.Forms.Control numericUpDown15 = this.NumericUpDown4;
			size = new global::System.Drawing.Size(72, 20);
			numericUpDown15.Size = size;
			this.NumericUpDown4.TabIndex = 4;
			this.NumericUpDown4.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.Label5.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label9 = this.Label5;
			location = new global::System.Drawing.Point(32, 56);
			label9.Location = location;
			this.Label5.Name = "Label5";
			global::System.Windows.Forms.Control label10 = this.Label5;
			size = new global::System.Drawing.Size(72, 16);
			label10.Size = size;
			this.Label5.TabIndex = 3;
			this.Label5.Text = "Pressure";
			this.Label5.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.NumericUpDown5.DecimalPlaces = 2;
			global::System.Windows.Forms.NumericUpDown numericUpDown16 = this.NumericUpDown5;
			num = new decimal(new int[]
			{
				2,
				0,
				0,
				131072
			});
			numericUpDown16.Increment = num;
			global::System.Windows.Forms.Control numericUpDown17 = this.NumericUpDown5;
			location = new global::System.Drawing.Point(120, 56);
			numericUpDown17.Location = location;
			global::System.Windows.Forms.NumericUpDown numericUpDown18 = this.NumericUpDown5;
			num = new decimal(new int[]
			{
				10,
				0,
				0,
				0
			});
			numericUpDown18.Maximum = num;
			global::System.Windows.Forms.NumericUpDown numericUpDown19 = this.NumericUpDown5;
			num = new decimal(new int[]
			{
				1,
				0,
				0,
				int.MinValue
			});
			numericUpDown19.Minimum = num;
			this.NumericUpDown5.Name = "NumericUpDown5";
			global::System.Windows.Forms.Control numericUpDown20 = this.NumericUpDown5;
			size = new global::System.Drawing.Size(72, 20);
			numericUpDown20.Size = size;
			this.NumericUpDown5.TabIndex = 2;
			this.NumericUpDown5.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.Label6.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label11 = this.Label6;
			location = new global::System.Drawing.Point(32, 24);
			label11.Location = location;
			this.Label6.Name = "Label6";
			global::System.Windows.Forms.Control label12 = this.Label6;
			size = new global::System.Drawing.Size(72, 16);
			label12.Size = size;
			this.Label6.TabIndex = 1;
			this.Label6.Text = "Weight";
			this.Label6.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			global::System.Windows.Forms.Control numericUpDown21 = this.NumericUpDown6;
			location = new global::System.Drawing.Point(120, 24);
			numericUpDown21.Location = location;
			global::System.Windows.Forms.NumericUpDown numericUpDown22 = this.NumericUpDown6;
			num = new decimal(new int[]
			{
				4500,
				0,
				0,
				0
			});
			numericUpDown22.Maximum = num;
			global::System.Windows.Forms.NumericUpDown numericUpDown23 = this.NumericUpDown6;
			num = new decimal(new int[]
			{
				500,
				0,
				0,
				int.MinValue
			});
			numericUpDown23.Minimum = num;
			this.NumericUpDown6.Name = "NumericUpDown6";
			global::System.Windows.Forms.Control numericUpDown24 = this.NumericUpDown6;
			size = new global::System.Drawing.Size(72, 20);
			numericUpDown24.Size = size;
			this.NumericUpDown6.TabIndex = 0;
			this.NumericUpDown6.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.GroupBox11.Controls.Add(this.Label9);
			this.GroupBox11.Controls.Add(this.NumericUpDown9);
			this.GroupBox11.Controls.Add(this.Label8);
			this.GroupBox11.Controls.Add(this.NumericUpDown8);
			this.GroupBox11.Controls.Add(this.Label7);
			this.GroupBox11.Controls.Add(this.NumericUpDown7);
			global::System.Windows.Forms.Control groupBox21 = this.GroupBox11;
			location = new global::System.Drawing.Point(8, 312);
			groupBox21.Location = location;
			this.GroupBox11.Name = "GroupBox11";
			global::System.Windows.Forms.Control groupBox22 = this.GroupBox11;
			size = new global::System.Drawing.Size(200, 152);
			groupBox22.Size = size;
			this.GroupBox11.TabIndex = 2;
			this.GroupBox11.TabStop = false;
			this.GroupBox11.Text = "Pressure";
			this.Label9.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label13 = this.Label9;
			location = new global::System.Drawing.Point(0, 104);
			label13.Location = location;
			this.Label9.Name = "Label9";
			global::System.Windows.Forms.Control label14 = this.Label9;
			size = new global::System.Drawing.Size(96, 16);
			label14.Size = size;
			this.Label9.TabIndex = 9;
			this.Label9.Text = "Press. Svivel";
			this.Label9.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.NumericUpDown9.DecimalPlaces = 2;
			global::System.Windows.Forms.NumericUpDown numericUpDown25 = this.NumericUpDown9;
			num = new decimal(new int[]
			{
				2,
				0,
				0,
				131072
			});
			numericUpDown25.Increment = num;
			global::System.Windows.Forms.Control numericUpDown26 = this.NumericUpDown9;
			location = new global::System.Drawing.Point(112, 104);
			numericUpDown26.Location = location;
			global::System.Windows.Forms.NumericUpDown numericUpDown27 = this.NumericUpDown9;
			num = new decimal(new int[]
			{
				10,
				0,
				0,
				0
			});
			numericUpDown27.Maximum = num;
			global::System.Windows.Forms.NumericUpDown numericUpDown28 = this.NumericUpDown9;
			num = new decimal(new int[]
			{
				1,
				0,
				0,
				int.MinValue
			});
			numericUpDown28.Minimum = num;
			this.NumericUpDown9.Name = "NumericUpDown9";
			global::System.Windows.Forms.Control numericUpDown29 = this.NumericUpDown9;
			size = new global::System.Drawing.Size(72, 20);
			numericUpDown29.Size = size;
			this.NumericUpDown9.TabIndex = 8;
			this.NumericUpDown9.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.Label8.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label15 = this.Label8;
			location = new global::System.Drawing.Point(0, 64);
			label15.Location = location;
			this.Label8.Name = "Label8";
			global::System.Windows.Forms.Control label16 = this.Label8;
			size = new global::System.Drawing.Size(96, 16);
			label16.Size = size;
			this.Label8.TabIndex = 7;
			this.Label8.Text = "Press. Pipe";
			this.Label8.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.NumericUpDown8.DecimalPlaces = 2;
			global::System.Windows.Forms.NumericUpDown numericUpDown30 = this.NumericUpDown8;
			num = new decimal(new int[]
			{
				2,
				0,
				0,
				131072
			});
			numericUpDown30.Increment = num;
			global::System.Windows.Forms.Control numericUpDown31 = this.NumericUpDown8;
			location = new global::System.Drawing.Point(112, 64);
			numericUpDown31.Location = location;
			global::System.Windows.Forms.NumericUpDown numericUpDown32 = this.NumericUpDown8;
			num = new decimal(new int[]
			{
				10,
				0,
				0,
				0
			});
			numericUpDown32.Maximum = num;
			global::System.Windows.Forms.NumericUpDown numericUpDown33 = this.NumericUpDown8;
			num = new decimal(new int[]
			{
				1,
				0,
				0,
				int.MinValue
			});
			numericUpDown33.Minimum = num;
			this.NumericUpDown8.Name = "NumericUpDown8";
			global::System.Windows.Forms.Control numericUpDown34 = this.NumericUpDown8;
			size = new global::System.Drawing.Size(72, 20);
			numericUpDown34.Size = size;
			this.NumericUpDown8.TabIndex = 6;
			this.NumericUpDown8.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.Label7.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label17 = this.Label7;
			location = new global::System.Drawing.Point(0, 24);
			label17.Location = location;
			this.Label7.Name = "Label7";
			global::System.Windows.Forms.Control label18 = this.Label7;
			size = new global::System.Drawing.Size(96, 16);
			label18.Size = size;
			this.Label7.TabIndex = 5;
			this.Label7.Text = "Press. Compr";
			this.Label7.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.NumericUpDown7.DecimalPlaces = 2;
			global::System.Windows.Forms.NumericUpDown numericUpDown35 = this.NumericUpDown7;
			num = new decimal(new int[]
			{
				2,
				0,
				0,
				131072
			});
			numericUpDown35.Increment = num;
			global::System.Windows.Forms.Control numericUpDown36 = this.NumericUpDown7;
			location = new global::System.Drawing.Point(112, 24);
			numericUpDown36.Location = location;
			global::System.Windows.Forms.NumericUpDown numericUpDown37 = this.NumericUpDown7;
			num = new decimal(new int[]
			{
				10,
				0,
				0,
				0
			});
			numericUpDown37.Maximum = num;
			global::System.Windows.Forms.NumericUpDown numericUpDown38 = this.NumericUpDown7;
			num = new decimal(new int[]
			{
				1,
				0,
				0,
				int.MinValue
			});
			numericUpDown38.Minimum = num;
			this.NumericUpDown7.Name = "NumericUpDown7";
			global::System.Windows.Forms.Control numericUpDown39 = this.NumericUpDown7;
			size = new global::System.Drawing.Size(72, 20);
			numericUpDown39.Size = size;
			this.NumericUpDown7.TabIndex = 4;
			this.NumericUpDown7.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.GroupBox12.Controls.Add(this.Label13);
			this.GroupBox12.Controls.Add(this.NumericUpDown13);
			this.GroupBox12.Controls.Add(this.Label12);
			this.GroupBox12.Controls.Add(this.NumericUpDown12);
			this.GroupBox12.Controls.Add(this.Label11);
			this.GroupBox12.Controls.Add(this.NumericUpDown11);
			this.GroupBox12.Controls.Add(this.Label10);
			this.GroupBox12.Controls.Add(this.NumericUpDown10);
			global::System.Windows.Forms.Control groupBox23 = this.GroupBox12;
			location = new global::System.Drawing.Point(216, 320);
			groupBox23.Location = location;
			this.GroupBox12.Name = "GroupBox12";
			global::System.Windows.Forms.Control groupBox24 = this.GroupBox12;
			size = new global::System.Drawing.Size(216, 144);
			groupBox24.Size = size;
			this.GroupBox12.TabIndex = 3;
			this.GroupBox12.TabStop = false;
			this.GroupBox12.Text = "Depth and Speed";
			this.Label13.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label19 = this.Label13;
			location = new global::System.Drawing.Point(0, 40);
			label19.Location = location;
			this.Label13.Name = "Label13";
			global::System.Windows.Forms.Control label20 = this.Label13;
			size = new global::System.Drawing.Size(104, 16);
			label20.Size = size;
			this.Label13.TabIndex = 9;
			this.Label13.Text = "Drill Length";
			this.Label13.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.NumericUpDown13.DecimalPlaces = 2;
			global::System.Windows.Forms.NumericUpDown numericUpDown40 = this.NumericUpDown13;
			num = new decimal(new int[]
			{
				1,
				0,
				0,
				131072
			});
			numericUpDown40.Increment = num;
			global::System.Windows.Forms.Control numericUpDown41 = this.NumericUpDown13;
			location = new global::System.Drawing.Point(112, 40);
			numericUpDown41.Location = location;
			global::System.Windows.Forms.NumericUpDown numericUpDown42 = this.NumericUpDown13;
			num = new decimal(new int[]
			{
				25,
				0,
				0,
				0
			});
			numericUpDown42.Maximum = num;
			global::System.Windows.Forms.NumericUpDown numericUpDown43 = this.NumericUpDown13;
			num = new decimal(new int[]
			{
				5,
				0,
				0,
				0
			});
			numericUpDown43.Minimum = num;
			this.NumericUpDown13.Name = "NumericUpDown13";
			global::System.Windows.Forms.Control numericUpDown44 = this.NumericUpDown13;
			size = new global::System.Drawing.Size(72, 20);
			numericUpDown44.Size = size;
			this.NumericUpDown13.TabIndex = 8;
			this.NumericUpDown13.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown numericUpDown45 = this.NumericUpDown13;
			num = new decimal(new int[]
			{
				10,
				0,
				0,
				0
			});
			numericUpDown45.Value = num;
			this.Label12.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label21 = this.Label12;
			location = new global::System.Drawing.Point(16, 104);
			label21.Location = location;
			this.Label12.Name = "Label12";
			global::System.Windows.Forms.Control label22 = this.Label12;
			size = new global::System.Drawing.Size(80, 16);
			label22.Size = size;
			this.Label12.TabIndex = 7;
			this.Label12.Text = "Drill Speed";
			this.Label12.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			global::System.Windows.Forms.Control numericUpDown46 = this.NumericUpDown12;
			location = new global::System.Drawing.Point(112, 104);
			numericUpDown46.Location = location;
			global::System.Windows.Forms.NumericUpDown numericUpDown47 = this.NumericUpDown12;
			num = new decimal(new int[]
			{
				240,
				0,
				0,
				0
			});
			numericUpDown47.Maximum = num;
			this.NumericUpDown12.Name = "NumericUpDown12";
			global::System.Windows.Forms.Control numericUpDown48 = this.NumericUpDown12;
			size = new global::System.Drawing.Size(72, 20);
			numericUpDown48.Size = size;
			this.NumericUpDown12.TabIndex = 6;
			this.NumericUpDown12.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.Label11.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label23 = this.Label11;
			location = new global::System.Drawing.Point(0, 72);
			label23.Location = location;
			this.Label11.Name = "Label11";
			global::System.Windows.Forms.Control label24 = this.Label11;
			size = new global::System.Drawing.Size(104, 16);
			label24.Size = size;
			this.Label11.TabIndex = 5;
			this.Label11.Text = "Ground Depth";
			this.Label11.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.NumericUpDown11.DecimalPlaces = 2;
			global::System.Windows.Forms.NumericUpDown numericUpDown49 = this.NumericUpDown11;
			num = new decimal(new int[]
			{
				1,
				0,
				0,
				131072
			});
			numericUpDown49.Increment = num;
			global::System.Windows.Forms.Control numericUpDown50 = this.NumericUpDown11;
			location = new global::System.Drawing.Point(112, 72);
			numericUpDown50.Location = location;
			global::System.Windows.Forms.NumericUpDown numericUpDown51 = this.NumericUpDown11;
			num = new decimal(new int[]
			{
				25,
				0,
				0,
				0
			});
			numericUpDown51.Maximum = num;
			global::System.Windows.Forms.NumericUpDown numericUpDown52 = this.NumericUpDown11;
			num = new decimal(new int[]
			{
				1,
				0,
				0,
				0
			});
			numericUpDown52.Minimum = num;
			this.NumericUpDown11.Name = "NumericUpDown11";
			global::System.Windows.Forms.Control numericUpDown53 = this.NumericUpDown11;
			size = new global::System.Drawing.Size(72, 20);
			numericUpDown53.Size = size;
			this.NumericUpDown11.TabIndex = 4;
			this.NumericUpDown11.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			global::System.Windows.Forms.NumericUpDown numericUpDown54 = this.NumericUpDown11;
			num = new decimal(new int[]
			{
				12,
				0,
				0,
				0
			});
			numericUpDown54.Value = num;
			this.Label10.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control label25 = this.Label10;
			location = new global::System.Drawing.Point(24, 16);
			label25.Location = location;
			this.Label10.Name = "Label10";
			global::System.Windows.Forms.Control label26 = this.Label10;
			size = new global::System.Drawing.Size(72, 16);
			label26.Size = size;
			this.Label10.TabIndex = 3;
			this.Label10.Text = "Depth";
			this.Label10.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.NumericUpDown10.DecimalPlaces = 2;
			global::System.Windows.Forms.NumericUpDown numericUpDown55 = this.NumericUpDown10;
			num = new decimal(new int[]
			{
				1,
				0,
				0,
				131072
			});
			numericUpDown55.Increment = num;
			global::System.Windows.Forms.Control numericUpDown56 = this.NumericUpDown10;
			location = new global::System.Drawing.Point(112, 16);
			numericUpDown56.Location = location;
			global::System.Windows.Forms.NumericUpDown numericUpDown57 = this.NumericUpDown10;
			num = new decimal(new int[]
			{
				25,
				0,
				0,
				0
			});
			numericUpDown57.Maximum = num;
			global::System.Windows.Forms.NumericUpDown numericUpDown58 = this.NumericUpDown10;
			num = new decimal(new int[]
			{
				12,
				0,
				0,
				int.MinValue
			});
			numericUpDown58.Minimum = num;
			this.NumericUpDown10.Name = "NumericUpDown10";
			global::System.Windows.Forms.Control numericUpDown59 = this.NumericUpDown10;
			size = new global::System.Drawing.Size(72, 20);
			numericUpDown59.Size = size;
			this.NumericUpDown10.TabIndex = 2;
			this.NumericUpDown10.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			size = new global::System.Drawing.Size(5, 13);
			this.AutoScaleBaseSize = size;
			size = new global::System.Drawing.Size(438, 475);
			this.ClientSize = size;
			this.ControlBox = false;
			this.Controls.Add(this.GroupBox12);
			this.Controls.Add(this.GroupBox11);
			this.Controls.Add(this.GroupBox6);
			this.Controls.Add(this.GroupBox1);
			this.KeyPreview = true;
			this.Name = "frmTest";
			this.Text = "Testing functions in soilmix program Press button F11 to close";
			this.GroupBox1.ResumeLayout(false);
			this.GroupBox5.ResumeLayout(false);
			this.GroupBox4.ResumeLayout(false);
			this.GroupBox3.ResumeLayout(false);
			this.GroupBox2.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown3).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown2).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown1).EndInit();
			this.GroupBox6.ResumeLayout(false);
			this.GroupBox7.ResumeLayout(false);
			this.GroupBox8.ResumeLayout(false);
			this.GroupBox9.ResumeLayout(false);
			this.GroupBox10.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown4).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown5).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown6).EndInit();
			this.GroupBox11.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown9).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown8).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown7).EndInit();
			this.GroupBox12.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown13).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown12).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown11).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.NumericUpDown10).EndInit();
			this.ResumeLayout(false);
		}

		// Token: 0x0400017C RID: 380
		private global::System.ComponentModel.IContainer components;
	}
}
